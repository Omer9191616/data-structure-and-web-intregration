<!DOCTYPE html>
<html>
<head>
    <title>Dream Home</title>
    <link rel="icon" type="image/png" href="./images/DreamHomeFavicon.png"/>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
    <link rel="stylesheet" type="text/css" href="styles/styles.css"/>
</head>
<body>
<!-- Begin Wrapper -->
<div id="wrapper">
    <?php
    //separate file for uniform navigation
    include './navigation.php';
    ?>
        <!-- Begin Two Columns -->
        <div id="twocolumns">
